function L = Lfunc(Gamma)

d = eig(Gamma);
isposdef = all(d > 0);

if isposdef == 1
    L = -log(det(Gamma));
else
    L = + Inf;

end


