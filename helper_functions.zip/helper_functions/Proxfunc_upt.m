function x = Proxfunc_upt(y,delta,tau)

%min_x 1/2 (x_y)^2 - tau*log(|x|+delta)

xtemp = [];
%positive x
D = (delta+y)^2 + 4*tau;
x1 = (y-delta - sqrt(D))/2;
x2 = (y-delta + sqrt(D))/2;
if x1 > 0
    xtemp = [xtemp x1];
end
if x2 > 0
    xtemp = [xtemp x2];
end

%negative x
D_ = (y-delta)^2 - 4*tau;
x3 = (y+delta - sqrt(D_))/2;
x4 = (y+delta + sqrt(D_))/2;
if x3 < 0 && isreal(x3)
    xtemp = [xtemp x3];
end
if x4 < 0 && isreal(x4)
    xtemp = [xtemp x4];
end

f = @(x) 1/2.*(x-y).^2 - tau*log(abs(x)+delta);
ftemp = f(xtemp);
 

[~,idx] = min(ftemp);
x = xtemp(idx);
end