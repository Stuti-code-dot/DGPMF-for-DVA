function [S] = Sfunc_vec(C,tau) % L_mu == mu

tmp = abs(C) - tau;
% idx_neg = tmp <=0;
idx_pos = tmp >0;
S = zeros(size(C));
S(idx_pos) = tmp(idx_pos);
% S = sign(C)*max(0,abs(C)-tau);
% S = sign(C)*max(0,(abs(C-tau)));
% S = real(S);
end