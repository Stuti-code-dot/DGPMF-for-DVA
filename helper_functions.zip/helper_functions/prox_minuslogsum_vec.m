function p = prox_minuslogsum_vec(x,tau,delta)

p1m = ((x + delta) - sqrt((x - delta).^2 + 4.*tau ))./2;
p2p = ((x - delta) + sqrt((x + delta).^2 + 4.*tau ))./2;

phi = @(xb) minuslogsum(xb,tau,delta)+ 0.5*(x-xb).^2;

phip1m = phi(p1m);
phip2p = phi(p2p);

idx1 = x<= - tau/delta;
idx2 = (x>-tau/delta) & (x<tau/delta);
idx3 = x>=tau/delta;
idx_2_1 = phip1m > phip2p;
idx_2_2 = phip1m <= phip2p;

p = zeros(size(x));

p(idx1) = p1m(idx1);
p(idx3) = p2p(idx3);

p(idx2 & idx_2_1) = p2p(idx2 & idx_2_1);
p(idx2 & idx_2_2) = p1m(idx2 & idx_2_2);
