function [R_est] = GPMF_2layer(y,Sd,Sv,M,Mo, sizeR,rankr,sigma, lambda_U1,lambda_U3,lambda_r,scale_param, theta1, theta2)%mu,k,sigma,gama,lambda_U, lambda_V,scale_param

Ad = Sd;
At = Sv;
size(Ad);
size(At);

%initialize factors
R_tr=reshape( M(y,2) ,sizeR);
R=R_tr;
B = Mo;
% STEP 1: SVD DECOMPOSITION
% STEP 1
[F,S,T]=svd(R);
U1 = F(:,1:rankr(1)); %U1(U1<0)=0;
V1=S(1:rankr(1),1:rankr(1))*T(:,1:rankr(1))';
[F2,S2,T2]=svd(V1);
U2=F2(:,1:rankr(2)); %U2(U2<0)=0;
U3=S2(1:rankr(2),1:rankr(2))*T2(:,1:rankr(2))'; %U3(U3<0)=0;
[n,k1] = size(U1);
[k1,k2] = size(U2);
[k2,m] = size(U3);

outsweep=10;
% STEP 2 : INITIALIZATION
e_U1 = 0*eye(n,n);
e_U1_bar = 0*eye(n,n);
e_U3 = 0*eye(m,m);
e_U3_bar = 0*eye(m,m);
Gamma_U1 = scale_param*eye(n,n);
Gamma_U3 = scale_param*eye(m,m);
del1 = scale_param;
del2 = scale_param;
X = scale_param*eye(n,m); 
A = (B/sigma^2 + lambda_r*ones(size(B)));
gama =1; %CV1 = 1 % CV2 = not used % CV3 = 1.1

% Laplacian Matrices    
Dd = diag(sum(Ad)); 
Lr = Dd - Ad;
if(det(Dd)==0)
    Dd=0.1*eye(size(Dd))+Dd;
end
L_U1 = (Dd^(-0.5))*Lr*(Dd^(-0.5));
Dt = diag(sum(At)); 
Lc = Dt - At;
if(det(Dt)==0)
    Dt=0.1*eye(size(Dt))+Dt;
end
L_U3 = (Dt^(-0.5))*Lc*(Dt^(-0.5));

% Gamma_U1 = L_U1 + gama*eye(n,n); 
% Gamma_U3 = L_U3 + gama*eye(m,m);

for i=1:n
        for j=1:n
            if Ad(i,j) > 0 
                e_U1(i,j) = 1;
            end

            if Ad(i,j) <= 0
                e_U1_bar(i,j) = 1;
            end
        end
end

for i=1:m
        for j=1:m
            if At(i,j) > 0 
                e_U3(i,j) = 1;
            end

            if At(i,j) <= 0
                e_U3_bar(i,j) = 1;
            end
        end
end

for out = 1:outsweep
    out;
    
    U1_k=U1; U2_k=U2; U3_k=U3;
    Gamma_U1_k = Gamma_U1;
    Gamma_U3_k = Gamma_U3;
    %R_k = R;

    b = ((B.*R)/sigma^2 + lambda_r*U1_k*U2_k*U3_k);
    b_vec = b(:);
    X_upt = pcg(@(x)reshape(A.*reshape(x,n,m),length(b_vec),1),b_vec);
    X = reshape(X_upt, size(X));
    % STEP 4
    Q1 = lambda_r*((U2_k*U3_k)*(U2_k*U3_k)');
%     Q1(isinf(Q1)|isnan(Q1)) = 0.0;
    
    U1 = sylvester(Gamma_U1_k,Q1,(X*(U2_k*U3_k)'));  
%     U(isinf(U)|isnan(U)) = 0.0;

    % STEP 5
    %f_gamma = trace(U*U'*Gamma_U_k) + Lfunc;
    t1 = 2;
    for out2 = 1:t1
        Gamma_U1_tilda = Gamma_U1 - theta1*(U1*U1' - inv(Gamma_U1));
    
    %     for i=1:n
    %         for j=1:n
    %             if e_U_bar(i,j) == 1
    % %                 prox_g_gamma_1(i,j) = Sfunc(pinv(1+2*lambda_U*theta1)*Gamma_U_k(i,j),pinv(1+2*lambda_U*theta1));
    %                 Gamma_U(i,j) = Sfunc(pinv(1+2*lambda_U*theta1)*Gamma_U_k(i,j),pinv(1+2*lambda_U*theta1));
    %             end
    %         end
    %     end
    
        idx1 = e_U1_bar == 1;
        Gamma_U1(idx1) = Sfunc_vec(inv(1+2*lambda_U1*theta1)*Gamma_U1_tilda(idx1),inv(1+2*lambda_U1*theta1));
    
    %     for i=1:n
    %         for j=1:n
    %             if e_U(i,j) == 1
    % 
    % %                 prox_g_gamma_2 = prox_minuslogsum(Gamma_U_tilda(i,j),pinv(1+2*lambda_U(i,j)*theta1),del1);
    %                 Gamma_U(i,j) = prox_minuslogsum(Gamma_U_tilda(i,j),pinv(1+2*lambda_U*theta1),del1);
    %             end
    %         end
    %     end
        
        idx2 = e_U1 == 1;
        Gamma_U1(idx2) = prox_minuslogsum_vec((1/(1+2*lambda_U1*theta1)).*Gamma_U1_tilda(idx2),2*theta1*lambda_U1/(1+2*lambda_U1*theta1),del1);
    end

    % U2 UPDATE
    
    U2 = pinv(U1)*X*pinv(U3_k); 

    Q2 = lambda_r*((U1*U2)'*(U1*U2));
%     Q2(isinf(Q2)|isnan(Q2)) = 0.0;
    
    U3 = sylvester(Q2,Gamma_U3_k,(lambda_r*(U1*U2)'*X)); 
%     V(isinf(V)|isnan(V)) = 0.0;

    % STEP 5
    %f_gamma = trace(U*U'*Gamma_U_k) + Lfunc;
    t2 = 2;
    for out3 = 1:t2
        
        Gamma_U3_tilda = Gamma_U3 - theta2*(U3'*U3 - inv(Gamma_U3));

%     for i=1:m
%         for j=1:m
%             if e_V_bar(i,j) == 1
%                 prox_g_gamma_3 = Sfunc(pinv(1+2*lambda_V*theta2)*Gamma_V_k(i,j),pinv(1+2*lambda_V*theta2));
%                 Gamma_V(i,j) = prox_g_gamma_3;
%             end
%         end
%     end

        idx3 = e_U3_bar == 1;
        Gamma_U3(idx3) = Sfunc_vec(inv(1+2*lambda_U3*theta2)*Gamma_U3_tilda(idx3),inv(1+2*lambda_U3*theta2));

%     for i=1:m
%         for j=1:m
%             if e_V(i,j) == 1
%                 prox_g_gamma_4 = prox_minuslogsum(Gamma_V_tilda(i,j),pinv(1+2*lambda_V*theta2),del2);
%                 Gamma_V(i,j) = prox_g_gamma_4;
%             end
%         end
%     end

        idx4 = e_U3 == 1;
        Gamma_U3(idx4) = prox_minuslogsum_vec(inv(1+2*lambda_U3*theta2)*Gamma_U3_tilda(idx4),2*theta2*lambda_U3*inv(1+2*lambda_U3*theta2),del2);
    end


a1 =1/(2*sigma^2)*(norm(R_tr - B.*X,"fro")^2);
a2 = 0.5*trace(U1'*Gamma_U1*U1);
a3 = 0.5*trace(U3*Gamma_U3*U3');
a4 = (lambda_r/2)*(norm(X - U1*U2*U3,"fro")^2);
a5 =  - 0.5*logdet(Gamma_U1); % logdet function to avoid overflow/underflow
a6 =  - 0.5*logdet(Gamma_U3);
a7 = lambda_U1*sum(sum(e_U1_bar*abs(Gamma_U1)));
a8 = lambda_U3*sum(sum(e_U3_bar*abs(Gamma_U3)));
a9 =  - lambda_U1*(sum(sum(e_U1*(log(abs(Gamma_U1)+del1)))));
a10 =  - lambda_U3*(sum(sum(e_U3*(log(abs(Gamma_U3)+del2)))));
a11 = lambda_U1/2*(norm(Gamma_U1, 'fro')^2);
a12 = lambda_U3/2*(norm(Gamma_U3, 'fro')^2);
CF = (a1+a2+a3+real(a4)+a5+a6+a7+a8+a9+a10+a11+a12);
arr(out) = CF;

R_est = U1*U2*U3;
R_est(R_est<0.0)=0.0;

X_est = X;  
X_est(X_est<0.0)=0.0;

end
figure(1)
plot(arr)
ylabel('Loss Function')
xlabel('Iterations')
hFig =figure(1);
set(hFig, 'Position', [100 100 500*1 250*1])
end
