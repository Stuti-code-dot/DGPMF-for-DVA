function [ FinalavgPre,FinalavgRec] = precision_recall_gpmf(Y,n,cv_setting,predictionMethod,knum)

    for iter=1:n
        avgPre=0;
        avgRec=0;
        avgPre2=0;
        avgRec2=0;
        p=[];r=[]; f=[];

        nou=size(Y,2);
        for i=1:nou
        % for i=1

            getParameters(predictionMethod,cv_setting);
            [ auc,aupr,XcROC,YcROC,XcPR,YcPR, T ,y3] = get_CV_results_setting4(Y,i,cv_setting,predictionMethod);

            x = [min(y3,[],1);max(y3,[],1)];
        %     x
        %     y3
        %     x(1,:)

            b = bsxfun(@minus,y3,x(1,:));
            y3_norm = bsxfun(@rdivide,b,diff(x,1,1));
        %     y3_norm
            %knum=10;
                ypred=y3_norm(:,i);
        %         ypred,size(ypred),i
                [sortedValues,sortIndex] = sort(ypred,'descend');
                ind = sortIndex(1:knum);
        %         sortedValues,sortIndex,ind 
                ind
                ypred_new = round(ypred*10);
        %         ypred_new

                for j=1:size(Y,1)
                    ypred(j,1) = 0;
                end
        %         ypred
        %         ypred(ind)
                ypred(ind) = ypred_new(ind);
                ypred
                Y(:,i)

        %         unique(ypred)
        %         [c,cm,ind,per] = confusion.getMatrix((ypred)',double(Y(:,i)')); 
                c_mat = confusionchart(double(Y(:,i)),(ypred));
        %         i,cm
                c_mat;

                cm = c_mat.NormalizedValues;
                cm
                unique_vals = unique(Y(:,i));
                for j= [1,2,3,4,5,6,7,8,9,10,11]
                    j
                    a = (diag(cm));
                    a(j)
                    recall =  a(j) / (sum(cm(j,:)));
            %         recall
                    precision =  a(j) / sum(cm(:,j));

                    precision(isnan(precision)|isinf(precision) )=0;
                    recall(isnan(recall)| isinf(recall))=0;

                    precision
                    recall

                    avgPre=avgPre+ precision;
                    avgRec=avgRec+ recall;

                    avgPre
                    avgRec
                end

                avgPre1 = avgPre/11;
                avgRec1 = avgRec/11;

                avgPre1
                avgRec1
                
                avgPre2 = avgPre2 + avgPre1
                avgRec2 = avgRec2 + avgRec1

        end
        
    end
        knum;
        avgPre2 = avgPre2/n
        avgRec2 = avgRec2/n
        FinalavgPre=avgPre2/nou 
%         p=[p,avgPre1];
        FinalavgRec=avgRec2/nou 
%         r=[r,avgRec1];

    end
    
   