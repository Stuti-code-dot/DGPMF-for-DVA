function f = minuslogsum(x,tau,delta)

f = - tau.*log(abs(x) + delta);