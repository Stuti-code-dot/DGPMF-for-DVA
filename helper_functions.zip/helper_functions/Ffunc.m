function [f] = Ffunc(C,mu) % L_mu == mu

C(isinf(C)|isnan(C)) = 0;
[vec,val] = eig(C);
size(diag(val));
val(val<0) = 0;
% val
eig_val = diag(val);
f = 0.5*diag(eig_val + sqrt(eig_val.^2 + (4/mu))); 
end

