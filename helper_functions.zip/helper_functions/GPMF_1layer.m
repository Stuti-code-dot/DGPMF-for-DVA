function [R_est] = GPMF_1layer(y,Sd,Sv,M,Mo, sizeR,rankr,sigma, lambda_U,lambda_V,lambda_r,scale_param, theta1, theta2)%mu,k,sigma,gama,lambda_U, lambda_V,scale_param

Ad = Sd;
At = Sv;
size(Ad);
size(At);

%initialize factors
R_tr=reshape( M(y,2) ,sizeR);
R=R_tr;
B = Mo;
% STEP 1: SVD DECOMPOSITION
[F,S,T]=svd(R);
U = F(:,1:rankr);
V=S(1:rankr,1:rankr)*T(:,1:rankr)';
[n, k] = size(U);
[k, m] = size(V);
% n,m
% n,k,m

outsweep=10;
% STEP 2 : INITIALIZATION
e_U = 0.0*eye(n,n);
del1 = scale_param;
e_U_bar = 0.0*eye(n,n);
e_V = 0.0*eye(m,m);
del2 = scale_param;
e_V_bar = 0.0*eye(m,m);
Gamma_U = scale_param*eye(n,n);
Gamma_V = scale_param*eye(m,m);
X = scale_param*eye(n,m);
A = (B/sigma^2 + lambda_r*ones(size(B)));
gama = 1;

% Laplacian Matrices    
Dd = diag(sum(Ad)); 
Lr = Dd - Ad;  
if(det(Dd)==0)
    Dd=0.1*eye(size(Dd))+Dd;
end
L_U = (Dd^(-0.5))*Lr*(Dd^(-0.5));

Dt = diag(sum(At)); 
Lc = Dt - At;
if(det(Dt)==0)
    Dt=0.1*eye(size(Dt))+Dt;
end
L_V = (Dt^(-0.5))*Lc*(Dt^(-0.5));

% Gamma_U = L_U + gama*eye(n,n); 
% Gamma_V = L_V + gama*eye(m,m);
% A_vec = diag(A(:));
% A_vec

% b_vec = A_vec*X_vec;
% r = A_vec*X_vec - b_vec;
% p = -r;
% size(r')
% size(p)

for i=1:n
        for j=1:n
            if Ad(i,j) > 0 
                e_U(i,j) = 1;
            end

            if Ad(i,j) <= 0
                e_U_bar(i,j) = 1;
            end
        end
end

for i=1:m
        for j=1:m
            if At(i,j) > 0 
                e_V(i,j) = 1;
            end

            if At(i,j) <= 0
                e_V_bar(i,j) = 1;
            end
        end
end

% for out1 = 1:2

%     X_k = X_vec;
%     r_k = r;
%     p_k = p;
%     alpha = (-r_k'*p_k)/(p_k'*A_vec*p_k);
%     X_upt = X_k + alpha*p_k;
%     r = A_vec*X_upt - b_vec;
%     beta = (r'*A_vec*p_k)/(p_k'*A_vec*p_k);
%     p = -r + beta*p_k;
    
%end
% X
for out = 1:outsweep
    out;
    
    U_k=U; V_k=V;
    Gamma_U_k = Gamma_U;
    Gamma_V_k = Gamma_V;
    %R_k = R;
    
    b = ((B.*R)/sigma^2 + lambda_r*U_k*V_k);
    b_vec = b(:);
 
    %X_upt = pcg(A_vec,b_vec);
    X_upt = pcg(@(X)reshape(A.*reshape(X,n,m),length(b_vec),1),b_vec);
    X = reshape(X_upt, size(X));
    % STEP 4
    Q1 = lambda_r*(V_k*V_k');
%     Q1(isinf(Q1)|isnan(Q1)) = 0.0;
    
    U = sylvester(Gamma_U_k,Q1,(X*V_k'));  
%     U(isinf(U)|isnan(U)) = 0.0;

    % STEP 5
    %f_gamma = trace(U*U'*Gamma_U_k) + Lfunc;
    t1 = 5;
    for out2 = 1:t1
        Gamma_U_tilda = Gamma_U - theta1*(U*U' - inv(Gamma_U));

        idx1 = e_U_bar == 1;
        Gamma_U(idx1) = Sfunc_vec(inv(1+2*lambda_U*theta1)*Gamma_U_tilda(idx1),inv(1+2*lambda_U*theta1));
    
        idx2 = e_U == 1;
        Gamma_U(idx2) = prox_minuslogsum_vec((1/(1+2*lambda_U*theta1)).*Gamma_U_tilda(idx2),2*theta1*lambda_U/(1+2*lambda_U*theta1),del1);
    end

    Q2 = lambda_r*(U'*U);
%     Q2(isinf(Q2)|isnan(Q2)) = 0.0;
    
    V = sylvester(Q2,Gamma_V_k,(lambda_r*U'*X)); 
%     V(isinf(V)|isnan(V)) = 0.0;

    % STEP 5
    %f_gamma = trace(U*U'*Gamma_U_k) + Lfunc;
    t2 = 5;
    for out3 = 1:t2
        
        Gamma_V_tilda = Gamma_V - theta2*(V'*V - inv(Gamma_V));

        idx3 = e_V_bar == 1;
        Gamma_V(idx3) = Sfunc_vec(inv(1+2*lambda_V*theta2)*Gamma_V_tilda(idx3),inv(1+2*lambda_V*theta2));

        idx4 = e_V == 1;
        Gamma_V(idx4) = prox_minuslogsum_vec(inv(1+2*lambda_V*theta2)*Gamma_V_tilda(idx4),2*theta2*lambda_V*inv(1+2*lambda_V*theta2),del2);
    end

a1 =1/(2*sigma^2)*(norm(R_tr - B.*X,"fro")^2);
a2 = 0.5*trace(U'*Gamma_U*U);
a3 = 0.5*trace(V*Gamma_V*V');
a4 = (lambda_r/2)*(norm(X - U*V,"fro")^2);
a5 =  - 0.5*logdet(Gamma_U); % logdet function to avoid overflow/underflow
a6 =  - 0.5*logdet(Gamma_V);
a7 = lambda_U*sum(sum(e_U_bar*abs(Gamma_U)));
a8 = lambda_V*sum(sum(e_V_bar*abs(Gamma_V)));
a9 =  - lambda_U*(sum(sum(e_U*(log(abs(Gamma_U)+del1)))));
a10 =  - lambda_V*(sum(sum(e_V*(log(abs(Gamma_V)+del2)))));
a11 = lambda_U/2*(norm(Gamma_U, 'fro')^2);
a12 = lambda_V/2*(norm(Gamma_V, 'fro')^2);
CF =a1+a2+a3+real(a4)+a5+a6+a7+a8+a9+a10+a11+a12;
arr(out) = CF;

R_est = U*V;
R_est(R_est<0.0)=0.0;

X_est = X;  
% X_est(X_est<0.0)=0.0;
% 
end
figure(1)
plot(real(arr))
ylabel('Loss Function')
xlabel('Iterations')
hFig =figure(1);
set(hFig, 'Position', [100 100 500*1 250*1])
end

% CF = 1/(2*sigma^2)*(norm(R_tr - B.*X,"fro")^2) + 0.5*trace(U'*Gamma_U*U) + 0.5*trace(V*Gamma_V*V') + (lambda_r/2)*(norm(X - U*V,"fro")^2) - 0.5*log(det(Gamma_U))+ 0.5*log(det(Gamma_V))+ lambda_U*sum(sum(e_U_bar*abs(Gamma_U))) + lambda_V*sum(sum(e_V_bar*abs(Gamma_V))) - lambda_U*(sum(sum(e_U*(log(abs(Gamma_U)+del1))))) - lambda_V*(sum(sum(e_V*(log(abs(Gamma_V)+del2))))) + lambda_U/2*(norm(Gamma_U, 'fro')^2) + lambda_V/2*(norm(Gamma_V, 'fro')^2)  ;