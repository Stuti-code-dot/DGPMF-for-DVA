function getParameters(classifier,cv_setting)
%
% This function retrieves optimal parameter values based on the supplied
% algorithm, the CV scenario used and the dataset on which prediction will
% be performed.
%
% INPUT:
%  classifier:  algorithm to be used
%  cv_setting:          
%
% OUTPUT:
%  params:   optimal parameter values for given inputs


global k alpha  k1 k2 k3 k4 pp lamda mu1 mu2 mu sigma gama theta1 theta2
global num_iter p lambda_l lambda_d lambda_t lambda_U lambda_V lambda_r scale_param lambda_U1 lambda_U3 lambda_U4
global vartheta

    switch classifier

    case 'GPMF_1layer'
        switch cv_setting 
            case 1     
                pp=2; k=20; lambda_U = 1; lambda_V = 1;lambda_r = 1;sigma = 0.1; scale_param = 1; theta1 = 0.1; theta2 = 0.01;
            case 2
%                 pp=2; k=38; lambda_U = 0.01; lambda_V = 1;lambda_r =1;
%                 sigma = 0.5; scale_param = 1; theta1 = 0.01; theta2 =
%                 0.01; best
                pp=2; k=38; lambda_U = 0.01; lambda_V = 1;lambda_r =0.9; sigma = 0.5; scale_param = 1; theta1 = 0.01; theta2 = 0.01;
            case 3
                pp=2; k=38; lambda_U = 1; lambda_V = 0.1;lambda_r = 1; sigma = 1; scale_param = 1; theta1 = 0.01; theta2 = 0.01;
            case 4                
%                 pp=2; k=8; lambda_U = 0.01; lambda_V = 0.1;lambda_r = 1; sigma = 0.1; scale_param = 0.1; theta1 = 0.1; theta2 = 0.01; % GPMF_1layer
                pp=2; k=38; lambda_U = 0; lambda_V = 0;lambda_r =1; sigma = 0.5; scale_param = 1; theta1 = 0.01; theta2 = 0.01; %PMF

        end
        

    case 'GPMF_2layer'
        switch cv_setting 
            case 1  
%                  best pp=2; k1=15; k2 = 7;  lambda_U1 = 1; lambda_U3 = 1;lambda_r = 1;sigma = 2; scale_param = 0.9; theta1 = 0.1; theta2 = 0.01;
                pp=2; k1=15; k2 = 7;  lambda_U1 = 1; lambda_U3 = 1;lambda_r = 1;sigma = 2; scale_param = 0.001; theta1 = 0.1; theta2 = 0.01;
%                 pp=2; k1=17; k2 = 5;  lambda_U1 = 1; lambda_U3 = 0.01;lambda_r = 1;sigma = 1; scale_param = 1; theta1 = 0.1; theta2 = 0.01;
            case 2
%                 pp=2; k1=23; k2 = 12;  lambda_U1 = 0.01; lambda_U3 = 0.01;lambda_r = 0.1;sigma = 1; scale_param = 0.1; theta1 = 1; theta2 = 0.1;
                pp=2; k1=23; k2 = 8;  lambda_U1 = 1; lambda_U3 = 0.01;lambda_r = 0.1;sigma = 1; scale_param = 0.1; theta1 = 0.1; theta2 = 0.01;
            case 3
                pp=2; k1=23; k2 = 4;  lambda_U1 = 0.9; lambda_U3 = 1;lambda_r = 1;sigma = 1; scale_param = 1; theta1 = 0.1; theta2 = 0.01;
            case 4  
%                 drug_recom 
                pp=2; k1=23; k2 = 14;  lambda_U1 = 0.1; lambda_U3 = 1;lambda_r = 0.01;sigma = 0.5; scale_param = 1; theta1 = 1; theta2 = 0.1;
        % auc_aupr
%                 pp=2; k1=23; k2 = 8;  lambda_U1 = 1; lambda_U3 = 0.01;lambda_r = 0.1;sigma = 1; scale_param = 0.1; theta1 = 0.1; theta2 = 0.01;
        end

    case 'GPMF_3layer'
        switch cv_setting 
            case 1  
                pp=2; k1=38; k2 = 13;k3 = 7;  lambda_U1 = 0.8; lambda_U4 = 1;lambda_r = 1;sigma = 2; scale_param = 0.9; theta1 = 0.1; theta2 = 0.01;
%                 pp=2; k1=17; k2 = 17;k3 = 8;  lambda_U1 = 1; lambda_U4 = 0.01;lambda_r = 1;sigma = 1; scale_param = 1; theta1 = 0.1; theta2 = 0.01;
%                 pp=2; k1=23; k2 = 11;k3 = 7;  lambda_U1 = 0.7; lambda_U4 = 1;lambda_r = 1;sigma = 2.1; scale_param = 0.9; theta1 = 0.1; theta2 = 0.01;
            case 2
                pp=2; k1=23; k2 = 12 ;k3 = 11;  lambda_U1 = 0.1; lambda_U4 = 0.01;lambda_r = 0.01;sigma = 0.01; scale_param = 1; theta1 = 0.01; theta2 = 1;
%                 pp=2; k1=23; k2 = 12;k3 = 8;  lambda_U1 = 1; lambda_U4 = 0.01;lambda_r = 0.01;sigma = 1.5; scale_param = 0.1; theta1 = 0.01; theta2 = 0.01;
            case 3
                pp=2; k1=26; k2 = 26;k3 = 6;  lambda_U1 = 1; lambda_U4 = 1;lambda_r = 1;sigma = 1; scale_param = 1; theta1 = 0.1; theta2 = 0.01;
%                  pp=2; k1=23; k2 = 17;k3 = 5;  lambda_U1 = 1; lambda_U4 = 1;lambda_r = 1;sigma = 1; scale_param = 1; theta1 = 0.1; theta2 = 0.01;
            case 4                
                pp=2; k1=23; k2 = 12;k3 = 8;  lambda_U1 = 1; lambda_U4 = 0.01;lambda_r = 0.01;sigma = 1.5; scale_param = 0.1; theta1 = 0.01; theta2 = 0.01;
        end


    case 'grdmf_2layer'
        switch cv_setting 
            case 1                            
                pp=2; alpha=0.05; mu=100; k1=17; k2=15; vartheta=1;
            case 2              
                pp=2; alpha=0.01; mu=50; k1=20; k2=15; vartheta=10; 
            case 3
                pp=5; alpha=0.1; mu=10; k1=17; k2=10; vartheta=2;              
            case 4  %copied cv2 parameters since we hide 10% viruses in cv2                
                pp=2; alpha=0.01; mu=50; k1=20; k2=15; vartheta=10; 
        end
                   
                       
    case 'grdmf_3layer'
        switch cv_setting 
            case 1
                pp=5; alpha=1; mu=5; k1=23; k2=10;k3=7; vartheta=1;
            case 2
                pp=5; alpha=1; mu=0.01; k1=20; k2=15; k3=10; vartheta=1; 
            case 3
                pp=5; alpha=1.5; mu=5; k1=23; k2=10; k3=7; vartheta=2;

            case 4               
                pp=5; alpha=1; mu=0.01; k1=20; k2=15; k3=10; vartheta=1; 
        end
          
    case 'grmf'
          
        num_iter = 2;
            k = 100;
                      switch(cv_setting)
                        
                        case 1
%                            p=7; lambda_l = 0.0313; lambda_d = 0.01;lambda_t = 0.01;
                           p=2; lambda_l = 0.0313; lambda_d = 0.01;lambda_t = 0.05;
                          case 2
                          % old data optimal para:dnt chng to keep corona rsult p=3; lambda_l = 0.125; lambda_d = 0.3;lambda_t = 0.1; 
                           p=2; lambda_l = 0.0625; lambda_d = 0.0;lambda_t = 0.07; %1 extra drug predicted in grmf
                           case 3
                           %p=7 ;lambda_l =0.25; lambda_d =0.25;lambda_t =0.01; 
%                            p=2 ;lambda_l =0.0625; lambda_d =0.05;lambda_t =0.005;
                            p=2 ;lambda_l =0.0625; lambda_d =0.08;lambda_t =0.005;
                        case 4
                           p=2; lambda_l = 0.0625; lambda_d = 0.3;lambda_t = 0.05; %1 extra drug predicted    
                      end
                             
                                   
                                   
    case 'gr1bmc_ppxa'
           
        switch cv_setting 
            case 1
                pp=2;lamda=0.1;mu1=0.5;mu2=0.1;
            case 2
                pp=2;lamda=0.05;mu1=3;mu2=0.5;
            case 3
                pp=2;lamda=2;mu1=0.5;mu2=0.5;
            case 4
                pp=2;lamda=0.05;mu1=1;mu2=0.5;
        end

            
    case 'grmc_admm'
        switch cv_setting 
            case 1
                pp=2;lamda=0.0;mu1=0.01;mu2=0.02;
            case 2
                pp=2;lamda=0;mu1=0.0;mu2=0.01;
            case 3
                pp=2;lamda=0.01;mu1=0.1;mu2=0.7;
            case 4
                pp=2;lamda=0.01;mu1=0.05;mu2=0.01;
        end

        case 'mf'
                    switch cv_setting 
                        case 1
                            k=5;alpha=1.5;    
                          case 2
                            k=15;alpha=0.01; 
                        case 3
                            k=20;alpha=0.01; 
                      end
       
      case 'dmf'
          switch cv_setting 
                        case 1
                            alpha=2; k1=25;k2=5;    
                          case 2
                            alpha=0.5; k1=25;k2=20;
                          case 3
                            alpha=0.5; k1=30;k2=15;
                            case 4
                            alpha=0.5; k1=25;k2=20;
                      end
            
            
    end
    