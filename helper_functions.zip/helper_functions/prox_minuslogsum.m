function p = prox_minuslogsum(x,tau,delta)

p1m = ((x + delta) - sqrt((x - delta).^2 + 4.*tau ))./2;
%p1p = ((x + delta) + sqrt((x - delta).^2 + 4.*tau ))./2

p2p = ((x - delta) + sqrt((x + delta).^2 + 4.*tau ))./2;
%p2m = ((x - delta) - sqrt((x + delta).^2 + 4.*tau ))./2


%X = linspace(-10,10,1000);

phi = @(xb) minuslogsum(xb,tau,delta)+ 0.5*(x-xb).^2;
%dphi = @(xb) der_minuslogsum(xb,tau,delta) + xb - x;


%phi0 = phi(0);
phip1m = phi(p1m);
phip2p = phi(p2p);


if x<= - tau/delta
    p = p1m;
   % phip = phip1m;
elseif x >= tau/delta
    p = p2p;
   % phip = phip2p;
else
    if phip1m > phip2p
        p = p2p;
      %  phip = phip2p;
    else
        p = p1m;
      %  phip = phip1m;
    end
end

% figure(1)
% plot(X,phi(X),'-b')
% hold on
% plot(0,phi0,'xr');
% hold on
% plot(p1m,phip1m,'xr');
% hold on
% plot(p2p,phip2p,'xr');
% hold on
% plot(p,phip,'*g');

% disp(['p1m = ',num2str(p1m)]);
% disp(['p2p = ',num2str(p2p)]);

%disp(p)

% figure(2)
% plot(X,dphi(X),'-b');
% hold on
% plot(p,dphi(p),'xr');

%disp(dphi(p))
% hold on
% plot(p1p,dphi(p1p),'or');
% hold on
% plot(p2m,dphi(p2m),'om');





