function [ FinalRMSE ] = RMSE_calc_gpmf(Y,n,cv_setting,predictionMethod,knum)


avgRMSE=0;

nou=size(Y,2);
for i=1:nou
% for i=1
    
    getParameters(predictionMethod,cv_setting);
    [ auc,aupr,XcROC,YcROC,XcPR,YcPR, T ,y3] = get_CV_results_setting4(Y,i,cv_setting,predictionMethod);

    x = [min(y3,[],1);max(y3,[],1)];
    b = bsxfun(@minus,y3,x(1,:));
    y3_norm = bsxfun(@rdivide,b,diff(x,1,1));
    
    %knum=10;
        ypred=y3_norm(:,i);
        ypred_copy = ypred;

        [sortedVlues,sortIndex] = sort(ypred,'descend');
        ind = sortIndex(1:knum);
%         sortedValues,sortIndex,ind 
        ind
        
        for j=1:size(Y,1)
            ypred(j,1) = 0;
        end
        ypred(ind) = round(ypred_copy(ind)*10);
        
        ypred
        Y(:,i)
        
        rmse = (Y(:,i)- ypred)^2;
        
        avgRMSE = avgRMSE+ rmse;
end
knum
FinalRMSE=(avgRMSE/nou)^0.5;

end

   