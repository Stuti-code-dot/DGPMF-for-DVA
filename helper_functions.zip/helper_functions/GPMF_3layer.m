function [R_est] = GPMF_3layer(y,Sd,Sv,M,Mo, sizeR,rankr,sigma, lambda_U1,lambda_U4,lambda_r,scale_param, theta1, theta2)%mu,k,sigma,gama,lambda_U, lambda_V,scale_param

Ad = Sd;
At = Sv;
size(Ad);
size(At);

%initialize factors
% initialize factors
R_tr=reshape( M(y,2) ,sizeR);
R=R_tr;
B = Mo;
[F,S,T]=svd(R);

U1 = F(:,1:rankr(1));% 
V1=S(1:rankr(1),1:rankr(1))*T(:,1:rankr(1))';

[F2,S2,T2]=svd(V1);
U2=F2(:,1:rankr(2));    %U2(U2<0)=0.0001;
V2=S2(1:rankr(2),1:rankr(2))*T2(:,1:rankr(2))';    %V(V<0)=0.0001;

[F3,S3,T3]=svd(V2);
U3=F3(:,1:rankr(3));    %U2(U2<0)=0.0001;
U4=S3(1:rankr(3),1:rankr(3))*T3(:,1:rankr(3))';    %V(V<0)=0.0001;

[n, k1] = size(U1);
[k1, k2] =size(U2)
[k2, k3] =size(U3)
[k3, m] = size(U4);

outsweep=10;
% STEP 2 : INITIALIZATION
e_U1 = 0*eye(n,n);
e_U1_bar = 0*eye(n,n);
e_U4 = 0*eye(m,m);
e_U4_bar = 0*eye(m,m);
Gamma_U1 = scale_param*eye(n,n);
Gamma_U4 = scale_param*eye(m,m);
del1 = scale_param;
del2 = scale_param;
X = scale_param*eye(n,m); 
A = (B/sigma^2 + lambda_r*ones(size(B)));
gama =1;

% Laplacian Matrices    
Dd = diag(sum(Ad)); 
Lr = Dd - Ad;
if(det(Dd)==0)
    Dd=0.1*eye(size(Dd))+Dd;
end
L_U1 = (Dd^(-0.5))*Lr*(Dd^(-0.5));
Dt = diag(sum(At)); 
Lc = Dt - At;
if(det(Dt)==0)
    Dt=0.1*eye(size(Dt))+Dt;
end
L_U4 = (Dt^(-0.5))*Lc*(Dt^(-0.5));

% Gamma_U1 = L_U1 + gama*eye(n,n); 
% Gamma_U4 = L_U4 + gama*eye(m,m);

for i=1:n
        for j=1:n
            if Ad(i,j) > 0 
                e_U1(i,j) = 1;
            end

            if Ad(i,j) <= 0
                e_U1_bar(i,j) = 1;
            end
        end
end

for i=1:m
        for j=1:m
            if At(i,j) > 0 
                e_U4(i,j) = 1;
            end

            if At(i,j) <= 0
                e_U4_bar(i,j) = 1;
            end
        end
end

for out = 1:outsweep
    out;
    
    U1_k=U1; U2_k=U2; U3_k=U3; U4_k=U4;
    Gamma_U1_k = Gamma_U1;
    Gamma_U4_k = Gamma_U4;
    %R_k = R;

    b = ((B.*R)/sigma^2 + lambda_r*U1_k*U2_k*U3_k*U4_k);
    b_vec = b(:);
    X_upt = pcg(@(x)reshape(A.*reshape(x,n,m),length(b_vec),1),b_vec);
    X = reshape(X_upt, size(X));
    % STEP 4
    Q1 = lambda_r*((U2_k*U3_k*U4_k)*(U2_k*U3_k*U4_k)');
%     Q1(isinf(Q1)|isnan(Q1)) = 0.0;
    
    U1 = sylvester(Gamma_U1_k,Q1,(X*(U2_k*U3_k*U4_k)'));  
%     U(isinf(U)|isnan(U)) = 0.0;

    % STEP 5
    %f_gamma = trace(U*U'*Gamma_U_k) + Lfunc;
    t1 = 2;
    for out2 = 1:t1
        Gamma_U1_tilda = Gamma_U1 - theta1*(U1*U1' - inv(Gamma_U1));
    
    %     for i=1:n
    %         for j=1:n
    %             if e_U_bar(i,j) == 1
    % %                 prox_g_gamma_1(i,j) = Sfunc(pinv(1+2*lambda_U*theta1)*Gamma_U_k(i,j),pinv(1+2*lambda_U*theta1));
    %                 Gamma_U(i,j) = Sfunc(pinv(1+2*lambda_U*theta1)*Gamma_U_k(i,j),pinv(1+2*lambda_U*theta1));
    %             end
    %         end
    %     end
    
        idx1 = e_U1_bar == 1;
        Gamma_U1(idx1) = Sfunc_vec(inv(1+2*lambda_U1*theta1)*Gamma_U1_tilda(idx1),inv(1+2*lambda_U1*theta1));
    
    %     for i=1:n
    %         for j=1:n
    %             if e_U(i,j) == 1
    % 
    % %                 prox_g_gamma_2 = prox_minuslogsum(Gamma_U_tilda(i,j),pinv(1+2*lambda_U(i,j)*theta1),del1);
    %                 Gamma_U(i,j) = prox_minuslogsum(Gamma_U_tilda(i,j),pinv(1+2*lambda_U*theta1),del1);
    %             end
    %         end
    %     end
        
        idx2 = e_U1 == 1;
        Gamma_U1(idx2) = prox_minuslogsum_vec((1/(1+2*lambda_U1*theta1)).*Gamma_U1_tilda(idx2),2*theta1*lambda_U1/(1+2*lambda_U1*theta1),del1);
    end

    % U2 UPDATE
    U2 = pinv(U1)*X*pinv(U3_k*U4_k);
     
    % U3 UPDATE
    U3 = pinv(U1*U2)*X*pinv(U4_k);

    Q2 = lambda_r*((U1*U2*U3)'*(U1*U2*U3));
%     Q2(isinf(Q2)|isnan(Q2)) = 0.0;
    
    U4 = sylvester(Q2,Gamma_U4_k,(lambda_r*(U1*U2*U3)'*X)); 
%     V(isinf(V)|isnan(V)) = 0.0;

    % STEP 5
    %f_gamma = trace(U*U'*Gamma_U_k) + Lfunc;
    t2 = 2;
    for out3 = 1:t2
        
        Gamma_U4_tilda = Gamma_U4 - theta2*(U4'*U4 - inv(Gamma_U4));

%     for i=1:m
%         for j=1:m
%             if e_V_bar(i,j) == 1
%                 prox_g_gamma_3 = Sfunc(pinv(1+2*lambda_V*theta2)*Gamma_V_k(i,j),pinv(1+2*lambda_V*theta2));
%                 Gamma_V(i,j) = prox_g_gamma_3;
%             end
%         end
%     end

        idx3 = e_U4_bar == 1;
        Gamma_U4(idx3) = Sfunc_vec(inv(1+2*lambda_U4*theta2)*Gamma_U4_tilda(idx3),inv(1+2*lambda_U4*theta2));

%     for i=1:m
%         for j=1:m
%             if e_V(i,j) == 1
%                 prox_g_gamma_4 = prox_minuslogsum(Gamma_V_tilda(i,j),pinv(1+2*lambda_V*theta2),del2);
%                 Gamma_V(i,j) = prox_g_gamma_4;
%             end
%         end
%     end

        idx4 = e_U4 == 1;
        Gamma_U4(idx4) = prox_minuslogsum_vec(inv(1+2*lambda_U4*theta2)*Gamma_U4_tilda(idx4),2*theta2*lambda_U4*inv(1+2*lambda_U4*theta2),del2);
    end



R_est = U1*U2*U3*U4;
R_est(R_est<0.0)=0.0;

% X_est = X;  
% X_est(X_est<0.0)=0.0;

end
end
